# Authorized Ingest (Webhook)

Endpoint:
- `POST /api/ingest/webhook/position`

Headers:
- `Content-Type: application/json`
- `X-Radar-Signature: sha256=<hex>` where `<hex>` is HMAC-SHA256 of the raw request body.

Environment:
- `RADAR_WEBHOOK_SECRET` (shared secret)

Payload (example):
```json
{
  "domain": "TRAIN",
  "public_id": "demo-train-001",
  "display_name": "Demo Train 001",
  "ts_utc": "2026-01-12T12:34:56Z",
  "lat": 41.881,
  "lon": -87.623,
  "reported_speed_mps": 14.2,
  "reported_heading_deg": 270.0,
  "operator": "Example Operator"
}
```

Notes:
- The server assigns/maintains an internal `object_id`.
- Fields are stored according to `visibility = AUTHORIZED`.
