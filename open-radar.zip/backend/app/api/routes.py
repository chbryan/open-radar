from __future__ import annotations

import json
from datetime import datetime, timezone, timedelta
from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse

import redis.asyncio as redis
from sqlalchemy import text

from app.core.types import ObjectState, HistoryPoint, PositionIn, Visibility
from app.core.tracker import STATE_KEY_PREFIX, OBJECT_SET_KEY, compute_status, ingest_position
from app.core.db import get_sessionmaker
from app.api.ws import ws_router

router = APIRouter()
router.include_router(ws_router)

def _utcnow() -> datetime:
    return datetime.now(timezone.utc)

def _get_cfg(request: Request):
    return request.app.state.cfg

def _get_redis(request: Request) -> redis.Redis:
    return request.app.state.redis

@router.get("/health")
async def health():
    return {"ok": True}

@router.get("/objects", response_model=List[ObjectState])
async def list_objects(
    request: Request,
    domain: Optional[str] = None,
    status: Optional[str] = None,
    visibility: Optional[str] = None,
    limit: int = 500,
):
    cfg = _get_cfg(request)
    r = _get_redis(request)

    ids = list(await r.smembers(OBJECT_SET_KEY))
    # Limit for sanity in public mode
    ids = ids[: max(0, min(limit, 5000))]

    out: List[ObjectState] = []
    for object_id in ids:
        raw = await r.get(f"{STATE_KEY_PREFIX}{object_id}")
        if not raw:
            continue
        try:
            st = ObjectState.model_validate_json(raw)
            st = await compute_status(cfg, st)
        except Exception:
            continue

        if domain and st.domain != domain:
            continue
        if visibility and st.visibility != visibility:
            continue
        if status and st.status != status:
            continue
        out.append(st)

    # Sort: active first, then recency
    order = {"ACTIVE": 0, "STALE": 1, "OFFLINE": 2}
    out.sort(key=lambda s: (order.get(s.status, 9), -s.last_seen_ts.timestamp()))
    return out[:limit]

@router.get("/objects/{object_id}", response_model=ObjectState)
async def get_object(request: Request, object_id: str):
    cfg = _get_cfg(request)
    r = _get_redis(request)
    raw = await r.get(f"{STATE_KEY_PREFIX}{object_id}")
    if not raw:
        raise HTTPException(status_code=404, detail="Object not found")
    st = ObjectState.model_validate_json(raw)
    st = await compute_status(cfg, st)
    return st

@router.get("/objects/{object_id}/history", response_model=List[HistoryPoint])
async def get_history(request: Request, object_id: str, minutes: int = 60, limit: int = 1000):
    minutes = max(1, min(minutes, 24 * 60))
    limit = max(1, min(limit, 5000))
    since = _utcnow() - timedelta(minutes=minutes)

    sm = get_sessionmaker()
    async with sm() as session:
        rows = (await session.execute(
            text("""
            SELECT ts_utc, lat, lon, speed_mps, heading_deg
            FROM radar_positions
            WHERE object_id = :object_id AND ts_utc >= :since
            ORDER BY ts_utc ASC
            LIMIT :limit;
            """),
            dict(object_id=object_id, since=since, limit=limit),
        )).all()

    return [HistoryPoint(ts_utc=r[0], lat=r[1], lon=r[2], speed_mps=r[3], heading_deg=r[4]) for r in rows]

# -----------------------------
# Authorized ingest (HMAC)
# -----------------------------

def _hmac_sha256_hex(secret: str, body: bytes) -> str:
    import hmac, hashlib
    return hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()

@router.post("/ingest/webhook/position", response_model=ObjectState)
async def ingest_webhook_position(request: Request):
    cfg = _get_cfg(request)
    r = _get_redis(request)

    body = await request.body()
    sig = request.headers.get("X-Radar-Signature", "")
    if not sig.startswith("sha256="):
        raise HTTPException(status_code=401, detail="Missing/invalid signature")
    sent = sig.split("=", 1)[1].strip().lower()
    calc = _hmac_sha256_hex(cfg.webhook_secret, body)
    # Constant-time compare
    import hmac
    if not hmac.compare_digest(sent, calc):
        raise HTTPException(status_code=401, detail="Signature mismatch")

    try:
        payload = json.loads(body.decode("utf-8"))
        pos = PositionIn.model_validate(payload)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Bad payload: {e}")

    st = await ingest_position(cfg, r, source="WEBHOOK", visibility="AUTHORIZED", pos=pos)
    return st
