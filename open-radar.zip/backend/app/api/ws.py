from __future__ import annotations

import asyncio
import json

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import redis.asyncio as redis

from app.core.tracker import UPDATES_CHANNEL, OBJECT_SET_KEY, STATE_KEY_PREFIX
from app.core.types import ObjectState
from app.core.tracker import compute_status

ws_router = APIRouter()

@ws_router.websocket("/ws")
async def radar_ws(ws: WebSocket):
    await ws.accept()
    app = ws.scope.get("app")  # FastAPI/Starlette instance
    cfg = app.state.cfg
    r: redis.Redis = app.state.redis

    pubsub = r.pubsub()
    await pubsub.subscribe(UPDATES_CHANNEL)

    try:
        # Initial snapshot
        ids = list(await r.smembers(OBJECT_SET_KEY))
        snapshot = []
        for object_id in ids[:2000]:
            raw = await r.get(f"{STATE_KEY_PREFIX}{object_id}")
            if not raw:
                continue
            try:
                st = ObjectState.model_validate_json(raw)
                st = await compute_status(cfg, st)
                snapshot.append(st.model_dump())
            except Exception:
                continue
        await ws.send_text(json.dumps({"type": "snapshot", "objects": snapshot}))

        # Stream updates
        while True:
            msg = await pubsub.get_message(ignore_subscribe_messages=True, timeout=1.0)
            if msg and msg.get("type") == "message":
                data = msg.get("data")
                try:
                    st = ObjectState.model_validate_json(data)
                    st = await compute_status(cfg, st)
                    await ws.send_text(json.dumps({"type": "update", "object": st.model_dump()}))
                except Exception:
                    pass
            await asyncio.sleep(0.05)
    except WebSocketDisconnect:
        pass
    finally:
        try:
            await pubsub.unsubscribe(UPDATES_CHANNEL)
            await pubsub.aclose()
        except Exception:
            pass
