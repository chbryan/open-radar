from __future__ import annotations
from typing import Literal, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime

Domain = Literal["VESSEL", "TRANSIT", "TRAIN"]
Visibility = Literal["PUBLIC", "AUTHORIZED"]
Status = Literal["ACTIVE", "STALE", "OFFLINE"]

class PositionIn(BaseModel):
    domain: Domain
    public_id: str
    display_name: str
    ts_utc: datetime
    lat: float
    lon: float
    reported_speed_mps: Optional[float] = None
    reported_heading_deg: Optional[float] = None
    operator: Optional[str] = None
    extra: Dict[str, Any] = Field(default_factory=dict)

class ObjectState(BaseModel):
    object_id: str
    domain: Domain
    public_id: str
    display_name: str
    operator: Optional[str] = None
    visibility: Visibility
    source: str
    status: Status
    last_seen_ts: datetime
    lat: float
    lon: float
    speed_mps: float
    heading_deg: float
    updated_at: datetime

class HistoryPoint(BaseModel):
    ts_utc: datetime
    lat: float
    lon: float
    speed_mps: Optional[float] = None
    heading_deg: Optional[float] = None
