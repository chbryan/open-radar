from __future__ import annotations
import math

EARTH_RADIUS_M = 6371008.8

def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    # Convert degrees to radians
    p = math.pi / 180.0
    dlat = (lat2 - lat1) * p
    dlon = (lon2 - lon1) * p
    a = (math.sin(dlat/2)**2 +
         math.cos(lat1*p) * math.cos(lat2*p) * math.sin(dlon/2)**2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return EARTH_RADIUS_M * c

def bearing_deg(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    # Bearing from point 1 to point 2
    p = math.pi / 180.0
    phi1 = lat1 * p
    phi2 = lat2 * p
    dlon = (lon2 - lon1) * p
    y = math.sin(dlon) * math.cos(phi2)
    x = math.cos(phi1)*math.sin(phi2) - math.sin(phi1)*math.cos(phi2)*math.cos(dlon)
    brng = math.atan2(y, x) / p
    return (brng + 360.0) % 360.0
