from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone, timedelta
from typing import Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
import redis.asyncio as redis

from app.core.config import RadarConfig
from app.core.db import get_sessionmaker
from app.core.geo import haversine_m, bearing_deg
from app.core.types import PositionIn, ObjectState, Visibility, Status

STATE_KEY_PREFIX = "radar:state:"
OBJECT_SET_KEY = "radar:objects"
UPDATES_CHANNEL = "radar:updates"

def _utcnow() -> datetime:
    return datetime.now(timezone.utc)

def _status_from_age(age_s: float, ttl_s: int) -> Status:
    if age_s <= ttl_s:
        return "ACTIVE"
    if age_s <= ttl_s * 5:
        return "STALE"
    return "OFFLINE"

async def upsert_object(
    session: AsyncSession,
    *,
    domain: str,
    public_id: str,
    display_name: str,
    operator: Optional[str],
    visibility: Visibility,
) -> str:
    object_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{domain}:{visibility}:{public_id}"))
    await session.execute(
        text("""
        INSERT INTO radar_objects (object_id, domain, public_id, display_name, operator, visibility)
        VALUES (:object_id, :domain, :public_id, :display_name, :operator, :visibility)
        ON CONFLICT (domain, public_id, visibility)
        DO UPDATE SET display_name = EXCLUDED.display_name,
                      operator = COALESCE(EXCLUDED.operator, radar_objects.operator);
        """),
        dict(
            object_id=object_id,
            domain=domain,
            public_id=public_id,
            display_name=display_name,
            operator=operator,
            visibility=visibility,
        ),
    )
    return object_id

async def write_history(
    session: AsyncSession,
    *,
    object_id: str,
    source: str,
    ts_utc: datetime,
    lat: float,
    lon: float,
    speed_mps: Optional[float],
    heading_deg: Optional[float],
    raw: dict,
) -> None:
    await session.execute(
        text("""
        INSERT INTO radar_positions (object_id, source, ts_utc, lat, lon, speed_mps, heading_deg, raw)
        VALUES (:object_id, :source, :ts_utc, :lat, :lon, :speed_mps, :heading_deg, :raw::jsonb);
        """),
        dict(
            object_id=object_id,
            source=source,
            ts_utc=ts_utc,
            lat=lat,
            lon=lon,
            speed_mps=speed_mps,
            heading_deg=heading_deg,
            raw=json.dumps(raw),
        ),
    )

async def ingest_position(
    cfg: RadarConfig,
    r: redis.Redis,
    *,
    source: str,
    visibility: Visibility,
    pos: PositionIn,
) -> ObjectState:
    # Normalize timestamp to UTC
    ts = pos.ts_utc
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    else:
        ts = ts.astimezone(timezone.utc)

    async_session = get_sessionmaker()
    async with async_session() as session:
        async with session.begin():
            object_id = await upsert_object(
                session,
                domain=pos.domain,
                public_id=pos.public_id,
                display_name=pos.display_name,
                operator=pos.operator,
                visibility=visibility,
            )

            # Load last state from Redis for speed/heading calc
            state_key = f"{STATE_KEY_PREFIX}{object_id}"
            last_raw = await r.get(state_key)
            last = json.loads(last_raw) if last_raw else None

            speed_mps = None
            heading_deg = None

            if pos.reported_speed_mps is not None:
                speed_mps = float(pos.reported_speed_mps)

            if pos.reported_heading_deg is not None:
                heading_deg = float(pos.reported_heading_deg)

            if last and (speed_mps is None or heading_deg is None):
                try:
                    last_ts = datetime.fromisoformat(last["last_seen_ts"])
                    if last_ts.tzinfo is None:
                        last_ts = last_ts.replace(tzinfo=timezone.utc)
                    dt = (ts - last_ts).total_seconds()
                    if dt > 0:
                        dist = haversine_m(last["lat"], last["lon"], pos.lat, pos.lon)
                        if speed_mps is None:
                            speed_mps = dist / dt
                        if heading_deg is None:
                            heading_deg = bearing_deg(last["lat"], last["lon"], pos.lat, pos.lon)
                except Exception:
                    pass

            if speed_mps is None:
                speed_mps = 0.0
            if heading_deg is None:
                heading_deg = 0.0

            # Smooth speed (simple EMA)
            if last:
                prev_speed = float(last.get("speed_mps", 0.0))
                alpha = 0.35
                speed_mps = alpha * speed_mps + (1 - alpha) * prev_speed

            updated_at = _utcnow()
            ttl_s = int(cfg.status_ttls_seconds.get(source, 120))
            status: Status = "ACTIVE"

            state = ObjectState(
                object_id=object_id,
                domain=pos.domain,
                public_id=pos.public_id,
                display_name=pos.display_name,
                operator=pos.operator,
                visibility=visibility,
                source=source,
                status=status,
                last_seen_ts=ts,
                lat=pos.lat,
                lon=pos.lon,
                speed_mps=speed_mps,
                heading_deg=heading_deg,
                updated_at=updated_at,
            )

            await write_history(
                session,
                object_id=object_id,
                source=source,
                ts_utc=ts,
                lat=pos.lat,
                lon=pos.lon,
                speed_mps=speed_mps,
                heading_deg=heading_deg,
                raw={"extra": pos.extra, "display_name": pos.display_name, "operator": pos.operator},
            )

        # Outside txn: update redis state, publish update
        await r.sadd(OBJECT_SET_KEY, object_id)
        await r.set(state_key, state.model_dump_json(), ex=max(ttl_s * 10, 600))
        await r.publish(UPDATES_CHANNEL, state.model_dump_json())

    return state

async def compute_status(cfg: RadarConfig, state: ObjectState) -> ObjectState:
    ttl_s = int(cfg.status_ttls_seconds.get(state.source, 120))
    age_s = (_utcnow() - state.last_seen_ts).total_seconds()
    status = _status_from_age(age_s, ttl_s)
    if status != state.status:
        return state.model_copy(update={"status": status})
    return state
