from __future__ import annotations

import asyncio
from typing import List

import redis.asyncio as redis

from app.core.config import RadarConfig, AdapterConfig
from app.adapters.sim import SimAdapter
from app.adapters.gtfs_rt import GtfsRtAdapter
from app.adapters.ais_ws import AisWsAdapter

class AdapterRunner:
    def __init__(self, cfg: RadarConfig, r: redis.Redis):
        self.cfg = cfg
        self.r = r
        self._tasks: List[asyncio.Task] = []
        self._stopping = asyncio.Event()

    async def start(self) -> None:
        for a in self.cfg.adapters:
            if not a.enabled:
                continue
            adapter = self._build(a)
            self._tasks.append(asyncio.create_task(adapter.run(self._stopping)))

    async def stop(self) -> None:
        self._stopping.set()
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)

    def _build(self, a: AdapterConfig):
        if a.type == "sim":
            return SimAdapter(self.cfg, self.r, a)
        if a.type == "gtfs_rt":
            return GtfsRtAdapter(self.cfg, self.r, a)
        if a.type == "ais_ws":
            return AisWsAdapter(self.cfg, self.r, a)
        raise ValueError(f"Unknown adapter type: {a.type}")
