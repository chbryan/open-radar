from __future__ import annotations

import redis.asyncio as redis
from app.core.config import RadarConfig

async def get_redis(cfg: RadarConfig) -> redis.Redis:
    r = redis.from_url(cfg.redis_url, decode_responses=True)
    # ping to validate connectivity
    await r.ping()
    return r
