from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import load_config
from app.core.db import init_db
from app.core.redis_client import get_redis
from app.core.runtime import AdapterRunner
from app.api.routes import router as api_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    cfg = load_config()
    app.state.cfg = cfg

    await init_db(cfg)
    r = await get_redis(cfg)
    app.state.redis = r

    runner = AdapterRunner(cfg, r)
    app.state.runner = runner
    await runner.start()

    try:
        yield
    finally:
        await runner.stop()
        await r.aclose()

app = FastAPI(title="Open Radar", version="0.1.0", lifespan=lifespan)

# Dev-friendly CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api")
