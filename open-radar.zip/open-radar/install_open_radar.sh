#!/usr/bin/env bash
set -euo pipefail

export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

log() { echo "[open-radar] $*"; }
die() { echo "[open-radar] ERROR: $*" >&2; exit 1; }

if [[ "${EUID}" -ne 0 ]]; then
  die "Please run as root (use: sudo bash install_open_radar.sh)"
fi

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET_USER="${SUDO_USER:-$(id -un)}"
TARGET_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6 || true)"

log "Target user: ${TARGET_USER}"
log "Script directory: ${SCRIPT_DIR}"

have_cmd() { command -v "$1" >/dev/null 2>&1; }

apt_install() {
  local pkgs=("$@")
  log "Installing packages: ${pkgs[*]}"
  apt-get update -y \
    -o Acquire::Retries=3 \
    -o Acquire::http::Timeout=20 \
    -o Acquire::https::Timeout=20
  apt-get install -y --no-install-recommends \
    -o Dpkg::Options::="--force-confnew" \
    "${pkgs[@]}"
}

# ---- Base deps ----
if have_cmd apt-get; then
  apt_install ca-certificates curl gnupg lsb-release git unzip
else
  die "This installer currently supports apt-based distros (Debian/Ubuntu)."
fi

# ---- Docker Engine ----
if ! have_cmd docker; then
  log "Docker not found. Installing docker.io from distro repos…"
  apt_install docker.io
else
  log "Docker already installed: $(docker --version || true)"
fi

# Start docker daemon (systemd or sysvinit)
if have_cmd systemctl; then
  systemctl enable --now docker >/dev/null 2>&1 || true
elif have_cmd service; then
  service docker start >/dev/null 2>&1 || true
fi

# ---- Docker Compose ----
compose_ok=0
if docker compose version >/dev/null 2>&1; then
  compose_ok=1
  log "Docker Compose v2 available: $(docker compose version | head -n1)"
fi

if [[ "$compose_ok" -eq 0 ]]; then
  # Try plugin first (some distros package it)
  if apt-cache show docker-compose-plugin >/dev/null 2>&1; then
    log "Installing docker-compose-plugin…"
    apt_install docker-compose-plugin
  fi

  if docker compose version >/dev/null 2>&1; then
    compose_ok=1
    log "Docker Compose v2 available: $(docker compose version | head -n1)"
  fi
fi

if [[ "$compose_ok" -eq 0 ]]; then
  # Fallback to legacy docker-compose
  if ! have_cmd docker-compose; then
    log "Docker Compose v2 not available. Installing legacy docker-compose…"
    apt_install docker-compose
  fi
  if have_cmd docker-compose; then
    compose_ok=2
    log "docker-compose available: $(docker-compose --version || true)"
  fi
fi

if [[ "$compose_ok" -eq 0 ]]; then
  die "Docker Compose is not available after installation attempts."
fi

# ---- Project setup ----
cd "$SCRIPT_DIR"

if [[ ! -f ".env" ]]; then
  log "Creating .env from .env.example"
  cp ".env.example" ".env"
else
  log ".env already exists; leaving it untouched."
fi

# Add user to docker group (optional; does not take effect until re-login)
if getent group docker >/dev/null 2>&1; then
  if id "$TARGET_USER" 2>/dev/null | grep -qv "\bdocker\b"; then
    log "Adding ${TARGET_USER} to docker group (takes effect after log out / log in)…"
    usermod -aG docker "$TARGET_USER" || true
  fi
fi

# Choose compose command for bring-up
if docker compose version >/dev/null 2>&1; then
  DC=(docker compose)
else
  DC=(docker-compose)
fi

log "Building and starting services…"
"${DC[@]}" up --build -d

log "Waiting for backend health endpoint…"
ok=0
for i in $(seq 1 90); do
  if curl -fsS "http://127.0.0.1:8000/api/health" >/dev/null 2>&1; then
    ok=1
    break
  fi
  sleep 1
done

if [[ "$ok" -ne 1 ]]; then
  log "Backend did not become healthy in time. Showing last 200 backend log lines:"
  "${DC[@]}" logs --tail=200 backend || true
  die "Backend failed to start."
fi

log "Install complete."
log "Open the UI at: http://localhost:5173"
