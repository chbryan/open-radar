from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from app.core.config import RadarConfig

_engine: AsyncEngine | None = None
_sessionmaker: async_sessionmaker[AsyncSession] | None = None


def get_engine() -> AsyncEngine:
    assert _engine is not None, "DB engine not initialized"
    return _engine


def get_sessionmaker() -> async_sessionmaker[AsyncSession]:
    assert _sessionmaker is not None, "DB sessionmaker not initialized"
    return _sessionmaker


async def init_db(cfg: RadarConfig) -> None:
    """Initialize the async SQLAlchemy engine and ensure required tables exist.

    Notes:
      * asyncpg (and many drivers) do NOT allow multi-statement SQL in a single
        prepared statement. Keep each DDL statement separate.
      * This function is safe to call multiple times.
    """
    global _engine, _sessionmaker

    if _engine is None:
        _engine = create_async_engine(cfg.postgres_dsn, pool_pre_ping=True)
        _sessionmaker = async_sessionmaker(_engine, expire_on_commit=False)

    assert _engine is not None

    async with _engine.begin() as conn:
        # PostGIS is optional but useful; harmless if already enabled.
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS postgis;"))

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS radar_objects (
                    object_id TEXT PRIMARY KEY,
                    domain TEXT NOT NULL,
                    public_id TEXT NOT NULL,
                    display_name TEXT NOT NULL,
                    operator TEXT,
                    visibility TEXT NOT NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    UNIQUE(domain, public_id, visibility)
                );
                """
            )
        )

        await conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS radar_positions (
                    id BIGSERIAL PRIMARY KEY,
                    object_id TEXT NOT NULL REFERENCES radar_objects(object_id) ON DELETE CASCADE,
                    source TEXT NOT NULL,
                    ts_utc TIMESTAMPTZ NOT NULL,
                    lat DOUBLE PRECISION NOT NULL,
                    lon DOUBLE PRECISION NOT NULL,
                    speed_mps DOUBLE PRECISION,
                    heading_deg DOUBLE PRECISION,
                    raw JSONB,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                );
                """
            )
        )

        await conn.execute(
            text(
                "CREATE INDEX IF NOT EXISTS idx_radar_positions_object_ts "
                "ON radar_positions(object_id, ts_utc DESC);"
            )
        )
        await conn.execute(
            text(
                "CREATE INDEX IF NOT EXISTS idx_radar_positions_ts "
                "ON radar_positions(ts_utc DESC);"
            )
        )
