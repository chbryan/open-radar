from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Awaitable, Callable, Type

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.exc import ProgrammingError

from app.api.routes import router as api_router
from app.core.config import load_config
from app.core.db import init_db
from app.core.redis_client import get_redis
from app.core.runtime import AdapterRunner

log = logging.getLogger("open_radar")


async def _retry(
    label: str,
    fn: Callable[[], Awaitable[object]],
    *,
    attempts: int = 60,
    delay_s: float = 1.0,
    fatal: tuple[Type[BaseException], ...] = (),
) -> object:
    last_exc: BaseException | None = None
    for i in range(1, attempts + 1):
        try:
            return await fn()
        except fatal:
            raise
        except Exception as e:  # noqa: BLE001
            last_exc = e
            log.warning("%s not ready (attempt %s/%s): %r", label, i, attempts, e)
            await asyncio.sleep(delay_s)
    raise RuntimeError(f"{label} not ready after {attempts} attempts: {last_exc!r}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Load config (YAML + env)
    cfg = load_config()
    app.state.cfg = cfg

    # Ensure DB schema exists; retry while Postgres is starting up.
    # If this ever fails with ProgrammingError, it's almost certainly a code/DDL bug,
    # not a readiness issue, so don't retry forever.
    await _retry("Postgres", lambda: init_db(cfg), fatal=(ProgrammingError,))

    # Connect to Redis; retry while Redis is starting up.
    r = await _retry("Redis", lambda: get_redis(cfg))
    app.state.redis = r

    # Start adapters (sim / gtfs / ais) in the background.
    runner = AdapterRunner(cfg, r)
    app.state.runner = runner
    await runner.start()

    try:
        yield
    finally:
        try:
            await runner.stop()
        finally:
            await r.aclose()


app = FastAPI(title="Open Radar", version="0.1.1", lifespan=lifespan)

# Dev-friendly CORS (local-only dashboard by default)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api")
