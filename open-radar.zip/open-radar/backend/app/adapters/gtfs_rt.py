from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Optional

import httpx
import redis.asyncio as redis
from google.transit import gtfs_realtime_pb2

from app.adapters.base import Adapter
from app.core.config import RadarConfig, AdapterConfig
from app.core.types import PositionIn
from app.core.tracker import ingest_position

def _dt_from_gtfs_ts(ts: int | None) -> datetime:
    if ts is None:
        return datetime.now(timezone.utc)
    return datetime.fromtimestamp(ts, tz=timezone.utc)

class GtfsRtAdapter(Adapter):
    """
    Polls a GTFS-Realtime VehiclePositions feed (and optionally TripUpdates/Alerts).
    Many agencies publish these publicly; each has its own terms and rate limits.
    """
    def __init__(self, cfg: RadarConfig, r: redis.Redis, a: AdapterConfig):
        self.cfg = cfg
        self.r = r
        self.a = a
        self.agency_id = a.raw.get("agency_id", "agency")
        self.vehicle_positions_url = a.raw.get("vehicle_positions_url", "")
        self.trip_updates_url = a.raw.get("trip_updates_url", "")
        self.alerts_url = a.raw.get("alerts_url", "")
        self.poll_seconds = int(a.raw.get("poll_seconds", 15))
        self.domain = a.raw.get("domain", "TRANSIT")

    async def run(self, stopping: asyncio.Event) -> None:
        if not self.vehicle_positions_url:
            # Adapter enabled but no URL; just idle.
            while not stopping.is_set():
                await asyncio.sleep(5.0)
            return

        async with httpx.AsyncClient(timeout=20.0) as client:
            while not stopping.is_set():
                try:
                    resp = await client.get(self.vehicle_positions_url)
                    resp.raise_for_status()
                    feed = gtfs_realtime_pb2.FeedMessage()
                    feed.ParseFromString(resp.content)
                    await self._process_vehicle_positions(feed)
                except Exception:
                    # In production you'd log this.
                    pass
                await asyncio.sleep(self.poll_seconds)

    async def _process_vehicle_positions(self, feed: gtfs_realtime_pb2.FeedMessage) -> None:
        for ent in feed.entity:
            if not ent.HasField("vehicle"):
                continue
            v = ent.vehicle
            if not v.HasField("position"):
                continue
            pos = v.position
            lat = float(pos.latitude)
            lon = float(pos.longitude)
            ts = _dt_from_gtfs_ts(v.timestamp if v.timestamp else None)

            # Best-effort IDs
            vehicle_id = ""
            if v.HasField("vehicle") and v.vehicle.id:
                vehicle_id = v.vehicle.id
            trip_id = v.trip.trip_id if v.HasField("trip") else ""
            route_id = v.trip.route_id if v.HasField("trip") else ""

            public_id = f"{self.agency_id}:{vehicle_id or trip_id or ent.id}"
            display = f"{self.agency_id} {route_id or ''} {vehicle_id or ''}".strip()
            if not display:
                display = public_id

            p = PositionIn(
                domain=self.domain,
                public_id=public_id,
                display_name=display,
                ts_utc=ts,
                lat=lat,
                lon=lon,
                reported_speed_mps=float(pos.speed) if pos.speed else None,
                reported_heading_deg=float(pos.bearing) if pos.bearing else None,
                operator=self.agency_id,
                extra={
                    "route_id": route_id,
                    "trip_id": trip_id,
                    "stop_id": v.stop_id if hasattr(v, "stop_id") else "",
                    "current_status": int(v.current_status) if v.current_status else None,
                },
            )
            await ingest_position(self.cfg, self.r, source="GTFS_RT", visibility="PUBLIC", pos=p)
