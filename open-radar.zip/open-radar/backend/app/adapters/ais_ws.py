from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime, timezone

import redis.asyncio as redis
import websockets

from app.adapters.base import Adapter
from app.core.config import RadarConfig, AdapterConfig
from app.core.types import PositionIn
from app.core.tracker import ingest_position

def _utcnow() -> datetime:
    return datetime.now(timezone.utc)

def _parse_any_ts(v) -> datetime:
    # Accept ISO8601 or unix seconds if present
    if v is None:
        return _utcnow()
    try:
        if isinstance(v, (int, float)):
            return datetime.fromtimestamp(float(v), tz=timezone.utc)
        if isinstance(v, str):
            # Allow "Z"
            if v.endswith("Z"):
                v = v[:-1] + "+00:00"
            dt = datetime.fromisoformat(v)
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return _utcnow()
    return _utcnow()

class AisWsAdapter(Adapter):
    """
    Optional AIS WebSocket adapter.
    This does NOT bundle any paid service; the user must provide a lawful websocket source.

    Expected message formats vary by provider. We support a minimal, flexible JSON schema:
      - mmsi (or MMSI)
      - lat/lon (or latitude/longitude)
      - sog (speed over ground) in knots OR speed_mps
      - cog (course over ground) in degrees OR heading_deg
      - timestamp (iso or unix)
      - name (optional)
      - operator (optional)

    Unknown messages are ignored.
    """
    def __init__(self, cfg: RadarConfig, r: redis.Redis, a: AdapterConfig):
        self.cfg = cfg
        self.r = r
        self.a = a
        url_env = a.raw.get("url_env", "AISSTREAM_URL")
        key_env = a.raw.get("api_key_env", "AISSTREAM_API_KEY")
        self.url = os.getenv(url_env, "") or a.raw.get("url", "")
        self.api_key = os.getenv(key_env, "") or a.raw.get("api_key", "")

    async def run(self, stopping: asyncio.Event) -> None:
        if not self.url:
            while not stopping.is_set():
                await asyncio.sleep(5.0)
            return

        headers = {}
        if self.api_key:
            headers["Authorization"] = self.api_key

        backoff = 1.0
        while not stopping.is_set():
            try:
                async with websockets.connect(self.url, extra_headers=headers) as ws:
                    backoff = 1.0
                    while not stopping.is_set():
                        msg = await asyncio.wait_for(ws.recv(), timeout=30.0)
                        await self._handle_message(msg)
            except Exception:
                await asyncio.sleep(backoff)
                backoff = min(backoff * 1.7, 30.0)

    async def _handle_message(self, msg: str) -> None:
        try:
            data = json.loads(msg)
        except Exception:
            return

        # Some providers wrap the payload
        payload = data.get("Message") or data.get("message") or data.get("data") or data

        mmsi = payload.get("mmsi") or payload.get("MMSI") or payload.get("userId") or payload.get("UserID")
        if not mmsi:
            return

        lat = payload.get("lat") or payload.get("latitude") or payload.get("Lat")
        lon = payload.get("lon") or payload.get("longitude") or payload.get("Lon")
        if lat is None or lon is None:
            return

        name = payload.get("name") or payload.get("ShipName") or f"MMSI {mmsi}"
        ts = _parse_any_ts(payload.get("timestamp") or payload.get("time") or payload.get("ts"))

        # Speed
        speed_mps = payload.get("speed_mps")
        if speed_mps is None:
            sog = payload.get("sog") or payload.get("SOG")
            if sog is not None:
                # knots -> m/s
                speed_mps = float(sog) * 0.514444

        heading = payload.get("heading_deg")
        if heading is None:
            cog = payload.get("cog") or payload.get("COG")
            if cog is not None:
                heading = float(cog)

        pos = PositionIn(
            domain="VESSEL",
            public_id=str(mmsi),
            display_name=str(name).strip() or f"MMSI {mmsi}",
            ts_utc=ts,
            lat=float(lat),
            lon=float(lon),
            reported_speed_mps=float(speed_mps) if speed_mps is not None else None,
            reported_heading_deg=float(heading) if heading is not None else None,
            operator=payload.get("operator"),
            extra={k: v for k, v in payload.items() if k not in {"lat","lon","latitude","longitude","mmsi","MMSI"}},
        )
        await ingest_position(self.cfg, self.r, source="AIS_WS", visibility="PUBLIC", pos=pos)
