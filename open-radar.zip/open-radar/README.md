# Open Radar (GPLv3)

Open Radar is a **Linux-first, self-hostable live map (“radar”)** for tracking moving objects using **publicly available**
feeds and **optional authorized integrations**.

It ships with an **always-on simulator** so anyone can run it locally with no external accounts or paid services.

## What it supports

- **Transit vehicles** (buses/rail where published) via **GTFS-Realtime** *(optional; public agency feeds)*
- **Vessels** via an **AIS WebSocket** adapter *(optional; requires an AIS provider + credentials)* or the simulator
- **Trains** via **GTFS-RT** where published *(public passenger rail / transit agencies)*, the simulator, and/or authorized webhooks

> Only connect to sources you are legally permitted to access and that comply with the source’s terms of use.

## Architecture

- **frontend**: Vite + React dashboard (port `5173`)
- **backend**: FastAPI + WebSocket updates (port `8000`)
- **db**: Postgres + PostGIS (port `5432`)
- **redis**: ephemeral object state + pub/sub (port `6379`)

Everything runs via **Docker Compose**.

## Quick start (recommended)

1) Download and unzip the project, then run:

```bash
cd open-radar
sudo bash install_open_radar.sh
```

2) Open the UI:

- http://localhost:5173

The simulator is enabled by default (see `config/radar.yaml`), so you should immediately see demo objects on the map.

## Manual run (no installer)

```bash
cd open-radar
cp -n .env.example .env
sudo docker compose up --build -d
sudo docker compose ps
curl -sS http://127.0.0.1:8000/api/health && echo
```

If your system only has legacy Compose, use:

```bash
sudo docker-compose up --build -d
```

Tip: You can also use the included helper:

```bash
./orad up
./orad logs backend
```

## Configuration

- `.env` contains runtime environment variables for Compose.
- `config/radar.yaml` controls adapters:
  - `sim` (enabled by default)
  - `gtfs_rt` (disabled by default; provide feed URLs you are allowed to use)
  - `ais_ws` (disabled by default; provide credentials via env vars)

### GTFS-Realtime (public)

Set `enabled: true` for the `gtfs_rt` adapter and provide the URL(s):

- `vehicle_positions_url`
- `trip_updates_url` *(optional)*
- `alerts_url` *(optional)*

### AIS WebSocket (authorized)

Set `enabled: true` for the `ais_ws` adapter and provide:

- `AISSTREAM_URL` and `AISSTREAM_API_KEY` in `.env`

## Authorized ingest (partners)

Partners can POST normalized position events to:

- `POST /api/ingest/webhook/position`

Header:

- `X-Radar-Signature: sha256=<hex>`

The signature is **HMAC-SHA256** over the raw request body using `RADAR_WEBHOOK_SECRET`.

See `docs/authorized-ingest.md`.

## Troubleshooting

### “permission denied while trying to connect to the Docker daemon socket”

Run Compose with `sudo`:

```bash
sudo docker compose ps
```

If you want Docker without sudo, add your user to the `docker` group and **log out / log in**:

```bash
sudo usermod -aG docker "$USER"
```

### Backend won’t start / crashes

Check logs:

```bash
sudo docker compose logs --tail=200 backend
```

The backend waits for Postgres/Redis readiness and the Compose file uses healthchecks, so repeated failures usually mean
a config issue or a port conflict.

### Port conflicts

Default ports: `5173` (frontend), `8000` (backend), `5432` (db), `6379` (redis).

If you already have something bound to one of those ports, change the host-side port mapping in `docker-compose.yml`.

## License

GPL-3.0. See `LICENSE`.
