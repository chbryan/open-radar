from __future__ import annotations
import asyncio
from abc import ABC, abstractmethod

class Adapter(ABC):
    @abstractmethod
    async def run(self, stopping: asyncio.Event) -> None:
        ...
