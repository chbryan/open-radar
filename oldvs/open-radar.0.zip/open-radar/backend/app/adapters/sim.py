from __future__ import annotations

import asyncio
import math
import random
from datetime import datetime, timezone
from typing import Dict

import redis.asyncio as redis

from app.adapters.base import Adapter
from app.core.config import RadarConfig, AdapterConfig
from app.core.types import PositionIn
from app.core.tracker import ingest_position

def _utcnow() -> datetime:
    return datetime.now(timezone.utc)

class SimAdapter(Adapter):
    """
    Offline simulator so anyone can run the system with $0 services.
    Generates a small set of demo vessels/transit vehicles/trains and moves them around.
    """
    def __init__(self, cfg: RadarConfig, r: redis.Redis, a: AdapterConfig):
        self.cfg = cfg
        self.r = r
        self.a = a
        raw = a.raw.get("objects", {})
        self.n_vessels = int(raw.get("vessels", 6))
        self.n_transit = int(raw.get("transit", 10))
        self.n_trains = int(raw.get("trains", 4))

        # Start near Chicago by default
        self.center_lat = float(a.raw.get("center_lat", 41.881))
        self.center_lon = float(a.raw.get("center_lon", -87.623))

        self._phase: Dict[str, float] = {}

    async def run(self, stopping: asyncio.Event) -> None:
        # Create IDs and phases
        ids = []
        for i in range(self.n_vessels):
            ids.append(("VESSEL", f"sim-vessel-{i:03d}", f"Sim Vessel {i:03d}"))
        for i in range(self.n_transit):
            ids.append(("TRANSIT", f"sim-transit-{i:03d}", f"Sim Transit {i:03d}"))
        for i in range(self.n_trains):
            ids.append(("TRAIN", f"sim-train-{i:03d}", f"Sim Train {i:03d}"))

        for _, pid, _ in ids:
            self._phase[pid] = random.random() * math.tau

        tick = 0
        while not stopping.is_set():
            tick += 1
            # Update each object
            for domain, public_id, name in ids:
                phase = self._phase[public_id] + tick * 0.04
                # Different radii by domain
                r_m = 15000 if domain == "VESSEL" else (8000 if domain == "TRAIN" else 5000)
                # Convert meters to lat/lon degrees approx
                dlat = (r_m / 111_320) * math.sin(phase)
                dlon = (r_m / (111_320 * math.cos(self.center_lat * math.pi/180))) * math.cos(phase)

                lat = self.center_lat + dlat
                lon = self.center_lon + dlon

                pos = PositionIn(
                    domain=domain, public_id=public_id, display_name=name,
                    ts_utc=_utcnow(), lat=lat, lon=lon,
                    reported_speed_mps=12.0 + (2.0 if domain == "TRAIN" else 0.0),
                    reported_heading_deg=(phase * 180.0 / math.pi) % 360.0,
                    operator="Simulator",
                    extra={"sim": True},
                )
                await ingest_position(self.cfg, self.r, source="SIM", visibility="PUBLIC", pos=pos)

            await asyncio.sleep(1.0)
