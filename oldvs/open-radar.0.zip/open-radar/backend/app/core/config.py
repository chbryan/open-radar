from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
import yaml
from typing import Any, Dict, List, Optional

@dataclass(frozen=True)
class AdapterConfig:
    type: str
    enabled: bool
    name: str
    raw: Dict[str, Any]

@dataclass(frozen=True)
class RadarConfig:
    version: int
    runtime: Dict[str, Any]
    status_ttls_seconds: Dict[str, int]
    adapters: List[AdapterConfig]
    postgres_dsn: str
    redis_url: str
    webhook_secret: str

def _env(name: str, default: str = "") -> str:
    v = os.getenv(name)
    return v if v is not None and v != "" else default

def load_config() -> RadarConfig:
    config_path = Path(_env("RADAR_CONFIG", "/app/config/radar.yaml"))
    data = yaml.safe_load(config_path.read_text(encoding="utf-8"))

    adapters = []
    for a in data.get("adapters", []):
        adapters.append(AdapterConfig(
            type=a["type"],
            enabled=bool(a.get("enabled", True)),
            name=a.get("name", a["type"]),
            raw=a,
        ))

    pg_host = _env("POSTGRES_HOST", "db")
    pg_port = _env("POSTGRES_PORT", "5432")
    pg_db = _env("POSTGRES_DB", "radar")
    pg_user = _env("POSTGRES_USER", "radar")
    pg_pass = _env("POSTGRES_PASSWORD", "radar")
    postgres_dsn = f"postgresql+asyncpg://{pg_user}:{pg_pass}@{pg_host}:{pg_port}/{pg_db}"

    redis_url = _env("REDIS_URL", "redis://redis:6379/0")
    webhook_secret = _env("RADAR_WEBHOOK_SECRET", "change-me")

    return RadarConfig(
        version=int(data.get("version", 1)),
        runtime=data.get("runtime", {}),
        status_ttls_seconds=data.get("status_ttls_seconds", {}),
        adapters=adapters,
        postgres_dsn=postgres_dsn,
        redis_url=redis_url,
        webhook_secret=webhook_secret,
    )
