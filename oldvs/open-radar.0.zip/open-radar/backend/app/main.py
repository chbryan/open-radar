# backend/app/main.py

from __future__ import annotations

import asyncio
import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import router as api_router
from app.core.config import load_config
from app.core.db import init_db, get_engine
from app.core.redis_client import get_redis
from app.core.runtime import AdapterRunner

logger = logging.getLogger("open-radar")


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except Exception:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except Exception:
        return default


async def _retry(
    label: str,
    fn,
    *,
    attempts: int,
    delay_s: float,
):
    """
    Retry an async operation with fixed delay.
    Intended for container startup ordering (db/redis may be 'running' but not 'ready').
    """
    last_exc: Exception | None = None
    for i in range(1, attempts + 1):
        try:
            return await fn()
        except Exception as e:
            last_exc = e
            logger.warning("%s not ready (attempt %d/%d): %r", label, i, attempts, e)
            await asyncio.sleep(delay_s)
    raise RuntimeError(f"{label} not ready after {attempts} attempts: {last_exc!r}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    cfg = load_config()
    app.state.cfg = cfg

    # Tunable startup behavior (defaults are sane for local docker compose)
    attempts = _env_int("RADAR_STARTUP_ATTEMPTS", 60)          # ~60 seconds max
    delay_s = _env_float("RADAR_STARTUP_DELAY_SECONDS", 1.0)  # 1s between tries

    # 1) Ensure Postgres is reachable and schema is initialized
    await _retry("Postgres", lambda: init_db(cfg), attempts=attempts, delay_s=delay_s)

    # 2) Ensure Redis is reachable
    r = await _retry("Redis", lambda: get_redis(cfg), attempts=attempts, delay_s=delay_s)
    app.state.redis = r

    # 3) Start adapters (SIM, GTFS-RT, AIS WS, etc.)
    runner = AdapterRunner(cfg, r)
    app.state.runner = runner
    await runner.start()

    try:
        yield
    finally:
        # Stop adapters first so they don't write while we're closing clients
        try:
            await runner.stop()
        except Exception:
            logger.exception("Error while stopping adapters")

        try:
            await r.aclose()
        except Exception:
            logger.exception("Error while closing Redis")

        # Dispose DB engine cleanly (ignore if not initialized for any reason)
        try:
            eng = get_engine()
            await eng.dispose()
        except Exception:
            pass


app = FastAPI(title="Open Radar", version="0.1.0", lifespan=lifespan)

# Dev-friendly CORS (tighten this later if you add auth)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api")

