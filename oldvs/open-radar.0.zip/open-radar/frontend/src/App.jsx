import React, { useEffect, useMemo, useRef, useState } from "react";
import MapView from "./components/MapView.jsx";
import Sidebar from "./components/Sidebar.jsx";

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8000";

function wsUrlFromApiBase(apiBase) {
  try {
    const u = new URL(apiBase);
    u.protocol = (u.protocol === "https:") ? "wss:" : "ws:";
    u.pathname = "/api/ws";
    u.search = "";
    u.hash = "";
    return u.toString();
  } catch {
    return "ws://localhost:8000/api/ws";
  }
}

export default function App() {
  const [objects, setObjects] = useState(() => new Map());
  const [selectedId, setSelectedId] = useState(null);

  const [filters, setFilters] = useState({
    domain: "",
    status: "ACTIVE",
    visibility: ""
  });

  const [trail, setTrail] = useState([]);
  const [trailLoading, setTrailLoading] = useState(false);

  const wsRef = useRef(null);

  const list = useMemo(() => {
    const arr = Array.from(objects.values());
    return arr.filter(o => {
      if (filters.domain && o.domain !== filters.domain) return false;
      if (filters.status && o.status !== filters.status) return false;
      if (filters.visibility && o.visibility !== filters.visibility) return false;
      return true;
    });
  }, [objects, filters]);

  const activeKnown = useMemo(() => {
    const arr = Array.from(objects.values());
    return arr
      .filter(o => o.status === "ACTIVE")
      .sort((a,b) => new Date(b.last_seen_ts) - new Date(a.last_seen_ts));
  }, [objects]);

  useEffect(() => {
    const url = wsUrlFromApiBase(API_BASE);
    const ws = new WebSocket(url);
    wsRef.current = ws;

    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === "snapshot") {
          const m = new Map();
          for (const o of msg.objects || []) {
            m.set(o.object_id, o);
          }
          setObjects(m);
        } else if (msg.type === "update" && msg.object) {
          setObjects(prev => {
            const m = new Map(prev);
            m.set(msg.object.object_id, msg.object);
            return m;
          });
        }
      } catch {}
    };

    ws.onclose = () => {
      // A simple reconnect loop could be added; kept minimal for MVP.
    };

    return () => {
      try { ws.close(); } catch {}
    };
  }, []);

  useEffect(() => {
    // Fetch trail when selection changes
    if (!selectedId) {
      setTrail([]);
      return;
    }
    let cancelled = false;
    async function run() {
      setTrailLoading(true);
      try {
        const res = await fetch(`${API_BASE}/api/objects/${selectedId}/history?minutes=60&limit=1000`);
        if (!res.ok) throw new Error("history fetch failed");
        const data = await res.json();
        if (!cancelled) setTrail(data);
      } catch {
        if (!cancelled) setTrail([]);
      } finally {
        if (!cancelled) setTrailLoading(false);
      }
    }
    run();
    return () => { cancelled = true; };
  }, [selectedId]);

  const selected = selectedId ? objects.get(selectedId) : null;

  return (
    <div className="app">
      <Sidebar
        objects={list}
        activeKnown={activeKnown}
        selectedId={selectedId}
        onSelect={setSelectedId}
        filters={filters}
        setFilters={setFilters}
        trailLoading={trailLoading}
      />
      <MapView
        objects={list}
        selected={selected}
        trail={trail}
      />
    </div>
  );
}
