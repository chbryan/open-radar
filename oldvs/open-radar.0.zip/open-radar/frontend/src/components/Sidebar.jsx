import React, { useMemo } from "react";

function fmtAge(ts) {
  const t = new Date(ts).getTime();
  const s = Math.max(0, (Date.now() - t) / 1000);
  if (s < 60) return `${Math.floor(s)}s`;
  if (s < 3600) return `${Math.floor(s/60)}m`;
  return `${Math.floor(s/3600)}h`;
}

function mpsToMph(mps) { return (mps || 0) * 2.236936; }

export default function Sidebar({
  objects,
  activeKnown,
  selectedId,
  onSelect,
  filters,
  setFilters,
  trailLoading
}) {
  const counts = useMemo(() => {
    const all = activeKnown.length;
    const vessels = activeKnown.filter(o => o.domain === "VESSEL").length;
    const transit = activeKnown.filter(o => o.domain === "TRANSIT").length;
    const trains = activeKnown.filter(o => o.domain === "TRAIN").length;
    return { all, vessels, transit, trains };
  }, [activeKnown]);

  return (
    <div className="sidebar">
      <div className="h1">Open Radar</div>

      <div className="row">
        <span className="badge">Active Known: {counts.all}</span>
        <span className="badge">Vessels: {counts.vessels}</span>
        <span className="badge">Transit: {counts.transit}</span>
        <span className="badge">Trains: {counts.trains}</span>
      </div>

      <div className="row">
        <select
          value={filters.domain}
          onChange={(e) => setFilters(f => ({...f, domain: e.target.value}))}
        >
          <option value="">All domains</option>
          <option value="VESSEL">Vessel</option>
          <option value="TRANSIT">Transit</option>
          <option value="TRAIN">Train</option>
        </select>

        <select
          value={filters.status}
          onChange={(e) => setFilters(f => ({...f, status: e.target.value}))}
        >
          <option value="">Any status</option>
          <option value="ACTIVE">Active</option>
          <option value="STALE">Stale</option>
          <option value="OFFLINE">Offline</option>
        </select>

        <select
          value={filters.visibility}
          onChange={(e) => setFilters(f => ({...f, visibility: e.target.value}))}
        >
          <option value="">Any visibility</option>
          <option value="PUBLIC">Public</option>
          <option value="AUTHORIZED">Authorized</option>
        </select>
      </div>

      <div className="small" style={{marginBottom: 10}}>
        Click an object to follow it and display its last 60 minutes trail.
        {trailLoading ? " (loading trail…)" : ""}
      </div>

      <div className="list">
        {objects.map(o => (
          <div
            key={o.object_id}
            className="card"
            style={{outline: o.object_id === selectedId ? "2px solid #111827" : "none"}}
            onClick={() => onSelect(o.object_id)}
            role="button"
            tabIndex={0}
          >
            <div className="card-title">{o.display_name}</div>
            <div className="small">
              {o.domain} • {o.visibility} • {o.status} • last {fmtAge(o.last_seen_ts)} ago
            </div>
            <div className="small">
              {Math.round(mpsToMph(o.speed_mps))} mph • hdg {Math.round(o.heading_deg)}°
            </div>
            {o.operator ? <div className="small">operator: {o.operator}</div> : null}
            <div className="small">id: {o.public_id}</div>
          </div>
        ))}
        {objects.length === 0 ? <div className="small">No objects match filters.</div> : null}
      </div>
    </div>
  );
}
