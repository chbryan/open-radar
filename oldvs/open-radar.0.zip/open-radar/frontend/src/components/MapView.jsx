import React, { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

function mpsToMph(mps) { return (mps || 0) * 2.236936; }

export default function MapView({ objects, selected, trail }) {
  const mapRef = useRef(null);
  const layersRef = useRef({
    markers: new Map(),
    trails: null,
    rings: null,
    center: { lat: 41.881, lon: -87.623 }
  });

  useEffect(() => {
    const map = L.map("map", { zoomControl: true }).setView([41.881, -87.623], 10);
    mapRef.current = map;

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: "&copy; OpenStreetMap contributors"
    }).addTo(map);

    const rings = L.layerGroup().addTo(map);
    layersRef.current.rings = rings;

    const trailsLayer = L.layerGroup().addTo(map);
    layersRef.current.trails = trailsLayer;

    function drawRings() {
      rings.clearLayers();
      const c = layersRef.current.center;
      const centerLatLng = L.latLng(c.lat, c.lon);
      [5000, 10000, 20000].forEach(r => {
        L.circle(centerLatLng, { radius: r, weight: 1, fill: false }).addTo(rings);
      });
    }

    drawRings();

    map.on("click", (e) => {
      layersRef.current.center = { lat: e.latlng.lat, lon: e.latlng.lng };
      drawRings();
    });

    return () => {
      map.remove();
    };
  }, []);

  // Update markers when objects change
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const markers = layersRef.current.markers;
    const seen = new Set();

    for (const o of objects) {
      seen.add(o.object_id);
      const key = o.object_id;
      const latlng = L.latLng(o.lat, o.lon);

      let cm = markers.get(key);
      if (!cm) {
        cm = L.circleMarker(latlng, { radius: 7, weight: 2, fillOpacity: 0.4 });
        cm.addTo(map);
        cm.bindTooltip(() => {
          const mph = Math.round(mpsToMph(o.speed_mps));
          return `${o.display_name}<br/>${o.domain} • ${o.status}<br/>${mph} mph • hdg ${Math.round(o.heading_deg)}°`;
        }, { direction: "top", sticky: true });
        markers.set(key, cm);
      } else {
        cm.setLatLng(latlng);
      }

      // Style by status
      if (o.status === "ACTIVE") {
        cm.setStyle({ dashArray: null, fillOpacity: 0.45 });
      } else if (o.status === "STALE") {
        cm.setStyle({ dashArray: "4 4", fillOpacity: 0.25 });
      } else {
        cm.setStyle({ dashArray: "1 6", fillOpacity: 0.10 });
      }
    }

    // Remove old markers
    for (const [key, cm] of markers.entries()) {
      if (!seen.has(key)) {
        cm.remove();
        markers.delete(key);
      }
    }
  }, [objects]);

  // Update trail + follow
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const trailsLayer = layersRef.current.trails;
    trailsLayer.clearLayers();

    if (trail && trail.length >= 2) {
      const pts = trail.map(p => [p.lat, p.lon]);
      const line = L.polyline(pts, { weight: 3 });
      line.addTo(trailsLayer);

      // Fit to trail bounds if selected
      const b = line.getBounds();
      if (b.isValid()) map.fitBounds(b, { padding: [40, 40] });
    } else if (selected) {
      map.setView([selected.lat, selected.lon], Math.max(map.getZoom(), 11));
    }
  }, [trail, selected]);

  return <div id="map" className="map" />;
}
